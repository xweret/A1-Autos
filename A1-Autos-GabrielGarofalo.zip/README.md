# A1-Autos

A1 autos es una aplicacion web diseñada para vender autos online - 

Es parte de mi entrega final para diplomatura de front-end en la universidad Tres de Febrero.

Sobre la idea:

Basicamente, con mi vieja tenemos un grupo de facebook de compra venta, el cual tiene actualmente mas de 75.000 usuarios de varias localidades limitrofes a nuestra ciudad, siempre he visto que hay un mercado 
muy grande para la compra y venta de autos. He de ahi que, para este desafio, intente usar tanto lo aprendido en la diplomatura, como lo que estudie el año pasado, marketing digital.

Sobre las herramientas usadas: 

Use HTML CSS y Js puros junto con algunas herramientas; para los "swipers" use la pagina  https://swiperjs.com/ que me encanto por su utilidad a la hora de hacer carrouseles responsives y que, para mi gusto, se ven realmente bien ademas, son muy customizables.
Para iconos y otras cosas relacionadas al estilo, use https://fontawesome.com/ ambos, conectados por CDN. El favicon lo diseñe con ilustrator.



Ver deploy en vivo: 
https://xweret.github.io/A1-Autos/

Imagen de la app en vivo: 

![image](https://user-images.githubusercontent.com/95048921/178765116-a03adaf3-b476-4f9b-bde8-4dbf95f8a83a.png)

Ver deploy en vivo: 

https://xweret.github.io/A1-Autos/
